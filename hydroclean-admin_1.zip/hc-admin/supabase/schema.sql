-- HydroClean Admin – database setup
-- Paste this whole file into Supabase → SQL Editor → New query → Run.
-- Every table is locked with Row Level Security: only the logged-in owner can read or change their own data.

create extension if not exists pgcrypto;

-- ---------- Settings (one row per user) ----------
create table if not exists settings (
  user_id uuid primary key default auth.uid() references auth.users on delete cascade,
  business_name text default 'Hydro Clean – Cleaning Specialists',
  tagline text default 'Garden Route Homes: Save Water, Clean Smarter!',
  address text default '4 Welbedacht Lane, Knysna, Western Cape, South Africa',
  phone text default '+27 069 464 5429',
  email text default 'info@hydro-clean.co.za',
  salesperson text default 'Jordy Erasmus',
  payment_terms text default '50% Deposit Secures Booking',
  bank_details text default '',
  vat_rate numeric default 0,
  quote_prefix text default 'Q',
  next_quote_no integer default 2702,
  default_terms text default 'This quote is valid for 30 days from the date above. A 50% deposit secures your booking, with the balance due on completion.
Work is subject to on-site confirmation of surface conditions. Any additional work beyond this scope will be quoted separately.',
  review_link text default '',
  wa_outreach text default 'Hi {business}, this is Jordy from HydroClean in Knysna. We pressure clean walkways, parking areas, roofs, decks and windows for local businesses around {town}. Would it be useful if I sent you a free, no-obligation quote? If not, no problem – just let me know and I won''t message again.',
  email_subject text default 'Quick question about cleaning at {business}',
  email_outreach text default 'Hi {business} team,

I''m Jordy from HydroClean, a local exterior cleaning company in Knysna. We pressure clean and soft wash walkways, parking areas, roofs, decks and windows for businesses around {town}, and can schedule work to suit you.

Would it be useful if I sent you a free, no-obligation quote?

If not, just reply "no thanks" and I won''t contact you again.

Kind regards,
Jordy Erasmus
HydroClean · 069 464 5429 · hydro-clean.co.za',
  updated_at timestamptz default now()
);

-- ---------- Clients ----------
create table if not exists clients (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null default auth.uid() references auth.users on delete cascade,
  name text not null,
  phone text, email text, address text, area text,
  type text default 'Residential',
  notes text,
  created_at timestamptz default now()
);

-- ---------- Leads (outreach) ----------
create table if not exists leads (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null default auth.uid() references auth.users on delete cascade,
  business text not null,
  segment text, category text, town text,
  contact_name text, phone text, email text, website text, address text, rating text,
  status text not null default 'new'
    check (status in ('new','contacted','replied','quoted','won','lost','do_not_contact')),
  last_contacted timestamptz,
  next_follow_up date,
  contact_count integer default 0,
  notes text,
  created_at timestamptz default now()
);

-- ---------- Quotes ----------
create table if not exists quotes (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null default auth.uid() references auth.users on delete cascade,
  number text,
  client_id uuid references clients on delete set null,
  lead_id uuid references leads on delete set null,
  client_name text, client_address text, client_phone text, client_email text,
  job_type text, salesperson text, payment_terms text,
  quote_date date default current_date,
  valid_days integer default 30,
  items jsonb default '[]'::jsonb,
  terms text,
  note text,
  vat_rate numeric default 0,
  total numeric default 0,
  status text not null default 'draft' check (status in ('draft','sent','accepted','declined')),
  created_at timestamptz default now()
);

-- ---------- Jobs ----------
create table if not exists jobs (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null default auth.uid() references auth.users on delete cascade,
  client_id uuid references clients on delete set null,
  quote_id uuid references quotes on delete set null,
  title text not null,
  client_name text, client_phone text, address text,
  scheduled_date date,
  status text not null default 'booked' check (status in ('booked','in_progress','done','cancelled')),
  amount numeric default 0,
  deposit_paid numeric default 0,
  balance_paid boolean default false,
  review_requested boolean default false,
  notes text,
  created_at timestamptz default now()
);

-- ---------- Money in / out ----------
create table if not exists transactions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null default auth.uid() references auth.users on delete cascade,
  tx_date date not null default current_date,
  type text not null check (type in ('income','expense')),
  category text,
  description text,
  amount numeric not null check (amount >= 0),
  job_id uuid references jobs on delete set null,
  created_at timestamptz default now()
);

-- ---------- Security: owner-only access ----------
do $$
declare t text;
begin
  foreach t in array array['settings','clients','leads','quotes','jobs','transactions'] loop
    execute format('alter table %I enable row level security', t);
    execute format('drop policy if exists owner_all on %I', t);
    execute format('create policy owner_all on %I for all to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid())', t);
  end loop;
end $$;

create index if not exists leads_user_status on leads (user_id, status);
create index if not exists jobs_user_date on jobs (user_id, scheduled_date);
create index if not exists tx_user_date on transactions (user_id, tx_date);
