import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import { useSettings } from '../lib/util';

const FIELDS = [
  ['Business', [
    ['business_name', 'Business name'], ['tagline', 'Tagline (top of quotes)'], ['address', 'Address'],
    ['phone', 'Phone'], ['email', 'Email'], ['salesperson', 'Salesperson / your name'],
  ]],
  ['Quotes', [
    ['quote_prefix', 'Quote number prefix'], ['next_quote_no', 'Next quote number', 'number'], ['vat_rate', 'VAT % (0 if not VAT registered)', 'number'],
    ['payment_terms', 'Default payment terms'], ['default_terms', 'Default terms & conditions (one per line)', 'area'],
    ['bank_details', 'Banking details shown on quotes (optional)', 'area'],
  ]],
  ['Messages', [
    ['review_link', 'Google review link (from your Business Profile → “Ask for reviews”)'],
    ['wa_outreach', 'WhatsApp outreach message – {business} and {town} fill in automatically', 'area'],
    ['email_subject', 'Outreach email subject'],
    ['email_outreach', 'Outreach email', 'area'],
  ]],
];

export default function Settings() {
  const [s, save] = useSettings();
  const [f, setF] = useState(null);
  const [msg, setMsg] = useState('');
  const [pw, setPw] = useState('');
  useEffect(() => { if (s) setF(s); }, [s]);
  if (!f) return <p className="muted">Loading…</p>;

  const submit = async () => {
    const { user_id, updated_at, ...vals } = f;
    try { await save(vals); setMsg('Settings saved.'); } catch (e) { setMsg(e.message); }
  };
  const changePw = async () => {
    if (pw.length < 8) return setMsg('Password needs at least 8 characters.');
    const { error } = await supabase.auth.updateUser({ password: pw });
    setMsg(error ? error.message : 'Password changed.'); setPw('');
  };

  return (
    <>
      <header className="page-head"><h1>Settings</h1><div className="actions"><button className="btn primary" onClick={submit}>Save settings</button></div></header>
      {msg && <p className="note">{msg}</p>}
      {FIELDS.map(([group, fields]) => (
        <section className="card" key={group}>
          <h3>{group}</h3>
          {fields.map(([k, label, type]) => (
            <label key={k}>{label}
              {type === 'area'
                ? <textarea rows={k.includes('outreach') ? 7 : 4} value={f[k] ?? ''} onChange={(e) => setF({ ...f, [k]: e.target.value })} />
                : <input type={type || 'text'} value={f[k] ?? ''} onChange={(e) => setF({ ...f, [k]: e.target.value })} />}
            </label>
          ))}
          {group === 'Messages' && <p className="muted small">Keep the first message a polite question with an easy “no thanks” – it keeps you on the right side of POPIA and gets better replies.</p>}
        </section>
      ))}
      <section className="card">
        <h3>Change password</h3>
        <div className="row2"><label>New password<input type="password" autoComplete="new-password" value={pw} onChange={(e) => setPw(e.target.value)} /></label><div style={{ alignSelf: 'end' }}><button className="btn" onClick={changePw}>Change password</button></div></div>
      </section>
    </>
  );
}
