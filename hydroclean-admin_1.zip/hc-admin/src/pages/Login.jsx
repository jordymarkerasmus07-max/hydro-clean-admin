import { useState } from 'react';
import { supabase } from '../lib/supabase';

export default function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [msg, setMsg] = useState('');
  const [busy, setBusy] = useState(false);

  const submit = async (e) => {
    e.preventDefault();
    setBusy(true); setMsg('');
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) setMsg('Wrong email or password.');
    setBusy(false);
  };
  const forgot = async () => {
    if (!email) return setMsg('Type your email first, then tap “Forgot password”.');
    await supabase.auth.resetPasswordForEmail(email, { redirectTo: window.location.origin });
    setMsg('If that email has an account, a reset link is on its way.');
  };

  return (
    <div className="center-screen">
      <form className="card narrow" onSubmit={submit}>
        <img src="/logo.png" alt="Hydro Clean" className="login-logo" />
        <h2 style={{ textAlign: 'center' }}>Admin login</h2>
        <label>Email<input type="email" autoComplete="username" value={email} onChange={(e) => setEmail(e.target.value)} required /></label>
        <label>Password<input type="password" autoComplete="current-password" value={password} onChange={(e) => setPassword(e.target.value)} required /></label>
        {msg && <p className="note">{msg}</p>}
        <button className="btn primary block" disabled={busy}>{busy ? 'Signing in…' : 'Sign in'}</button>
        <button type="button" className="link" onClick={forgot}>Forgot password</button>
      </form>
    </div>
  );
}

export function SetPassword({ onDone }) {
  const [pw, setPw] = useState('');
  const [msg, setMsg] = useState('');
  const save = async (e) => {
    e.preventDefault();
    if (pw.length < 8) return setMsg('Use at least 8 characters.');
    const { error } = await supabase.auth.updateUser({ password: pw });
    if (error) return setMsg(error.message);
    onDone();
  };
  return (
    <div className="center-screen">
      <form className="card narrow" onSubmit={save}>
        <img src="/logo.png" alt="Hydro Clean" className="login-logo" />
        <h2>Set a new password</h2>
        <label>New password<input type="password" autoComplete="new-password" value={pw} onChange={(e) => setPw(e.target.value)} /></label>
        {msg && <p className="note">{msg}</p>}
        <button className="btn primary block">Save password</button>
      </form>
    </div>
  );
}
