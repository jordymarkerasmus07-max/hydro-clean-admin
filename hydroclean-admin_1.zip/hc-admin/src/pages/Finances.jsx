import { useState } from 'react';
import { EXPENSE_CATEGORIES, INCOME_CATEGORIES } from '../lib/services';
import { downloadCSV, money, money0, monthKey, shortDate, today, useTable } from '../lib/util';

const monthName = (k) => new Date(k + '-01').toLocaleDateString('en-ZA', { month: 'short', year: '2-digit' });
const lastMonths = (n) => {
  const out = []; const d = new Date(); d.setDate(1);
  for (let i = 0; i < n; i++) { out.unshift(d.toISOString().slice(0, 7)); d.setMonth(d.getMonth() - 1); }
  return out;
};

export default function Finances() {
  const { rows, loading, insert, remove } = useTable('transactions', { order: 'tx_date' });
  const [month, setMonth] = useState(monthKey(today()));
  const [form, setForm] = useState({ type: 'expense', category: EXPENSE_CATEGORIES[0], description: '', amount: '', tx_date: today() });
  const [err, setErr] = useState('');
  const [hover, setHover] = useState(null);

  const inMonth = rows.filter((t) => monthKey(t.tx_date) === month);
  const sum = (list, type) => list.filter((t) => t.type === type).reduce((a, t) => a + +t.amount, 0);
  const inc = sum(inMonth, 'income'); const exp = sum(inMonth, 'expense');
  const year = month.slice(0, 4);
  const inYear = rows.filter((t) => String(t.tx_date).startsWith(year));
  const months = lastMonths(6);
  const series = months.map((m) => { const l = rows.filter((t) => monthKey(t.tx_date) === m); return { m, inc: sum(l, 'income'), exp: sum(l, 'expense') }; });
  const max = Math.max(1, ...series.flatMap((s) => [s.inc, s.exp]));
  const byCat = Object.entries(inMonth.filter((t) => t.type === 'expense').reduce((a, t) => ({ ...a, [t.category || 'Other']: (a[t.category || 'Other'] || 0) + +t.amount }), {})).sort((a, b) => b[1] - a[1]);
  const allMonths = [...new Set([monthKey(today()), ...rows.map((t) => monthKey(t.tx_date))])].sort().reverse();

  const add = async (e) => {
    e.preventDefault(); setErr('');
    if (!(+form.amount > 0)) return setErr('Enter an amount.');
    try { await insert({ ...form, amount: +form.amount }); setForm({ ...form, description: '', amount: '' }); } catch (x) { setErr(x.message); }
  };
  const setType = (type) => setForm({ ...form, type, category: (type === 'income' ? INCOME_CATEGORIES : EXPENSE_CATEGORIES)[0] });

  return (
    <>
      <header className="page-head">
        <h1>Finances</h1>
        <div className="actions">
          <select value={month} onChange={(e) => setMonth(e.target.value)}>{allMonths.map((m) => <option key={m} value={m}>{new Date(m + '-01').toLocaleDateString('en-ZA', { month: 'long', year: 'numeric' })}</option>)}</select>
          <button className="btn" onClick={() => downloadCSV(`hydroclean-finances-${year}.csv`, inYear.map(({ tx_date, type, category, description, amount }) => ({ date: tx_date, type, category, description, amount })))}>Export {year} (for tax)</button>
        </div>
      </header>

      <div className="stats">
        <div className="stat"><span>Money in</span><b>{money0(inc)}</b></div>
        <div className="stat"><span>Money out</span><b>{money0(exp)}</b></div>
        <div className={`stat ${inc - exp >= 0 ? 'good' : 'bad'}`}><span>Profit</span><b>{money0(inc - exp)}</b>{inc > 0 && <small>{Math.round(((inc - exp) / inc) * 100)}% margin</small>}</div>
        <div className="stat"><span>{year} profit so far</span><b>{money0(sum(inYear, 'income') - sum(inYear, 'expense'))}</b></div>
      </div>

      <div className="grid2">
        <section className="card">
          <div className="card-head"><h3>Last 6 months</h3>
            <div className="legend"><span><i className="sw inc" />Money in</span><span><i className="sw exp" />Money out</span></div>
          </div>
          <div className="bars" role="img" aria-label="Money in and out for the last six months; see the table below for values">
            {series.map((s, i) => (
              <div className="bar-group" key={s.m} onMouseEnter={() => setHover(i)} onMouseLeave={() => setHover(null)}>
                <div className="bar-pair">
                  <i className="bar inc" style={{ height: `${(s.inc / max) * 100}%` }} />
                  <i className="bar exp" style={{ height: `${(s.exp / max) * 100}%` }} />
                </div>
                <span className="bar-label">{monthName(s.m)}</span>
                {hover === i && <div className="tip"><b>{monthName(s.m)}</b><span><i className="sw inc" />In {money0(s.inc)}</span><span><i className="sw exp" />Out {money0(s.exp)}</span><span>Profit {money0(s.inc - s.exp)}</span></div>}
              </div>
            ))}
          </div>
          <table className="tbl compact">
            <thead><tr><th>Month</th><th className="r">In</th><th className="r">Out</th><th className="r">Profit</th></tr></thead>
            <tbody>{series.slice().reverse().map((s) => <tr key={s.m}><td>{monthName(s.m)}</td><td className="r">{money0(s.inc)}</td><td className="r">{money0(s.exp)}</td><td className="r"><b>{money0(s.inc - s.exp)}</b></td></tr>)}</tbody>
          </table>
        </section>

        <section className="card">
          <h3>Add money in / out</h3>
          <form onSubmit={add}>
            <div className="seg">
              <button type="button" className={form.type === 'income' ? 'on' : ''} onClick={() => setType('income')}>Money in</button>
              <button type="button" className={form.type === 'expense' ? 'on' : ''} onClick={() => setType('expense')}>Money out</button>
            </div>
            <div className="row2">
              <label>Amount (R)<input type="number" step="0.01" inputMode="decimal" value={form.amount} onChange={(e) => setForm({ ...form, amount: e.target.value })} /></label>
              <label>Date<input type="date" value={form.tx_date} onChange={(e) => setForm({ ...form, tx_date: e.target.value })} /></label>
            </div>
            <label>Category<select value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })}>{(form.type === 'income' ? INCOME_CATEGORIES : EXPENSE_CATEGORIES).map((c) => <option key={c}>{c}</option>)}</select></label>
            <label>Description<input value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} placeholder={form.type === 'income' ? 'e.g. Diane Palmer – paving balance' : 'e.g. Diesel for generator'} /></label>
            {err && <p className="note bad">{err}</p>}
            <button className="btn primary block">Add</button>
          </form>
          {byCat.length > 0 && (<>
            <h3 style={{ marginTop: 22 }}>Where the money went this month</h3>
            <ul className="list">{byCat.map(([c, v]) => <li key={c}><b>{c}</b><span className="muted">{money0(v)} · {Math.round((v / exp) * 100)}%</span></li>)}</ul>
          </>)}
        </section>
      </div>

      <section className="card">
        <h3>Transactions – {new Date(month + '-01').toLocaleDateString('en-ZA', { month: 'long', year: 'numeric' })}</h3>
        {loading ? <p className="muted">Loading…</p> : inMonth.length === 0 ? <p className="muted">Nothing recorded this month.</p> : (
          <div className="table-wrap">
            <table className="tbl">
              <thead><tr><th>Date</th><th>Category</th><th>Description</th><th className="r">Amount</th><th /></tr></thead>
              <tbody>{inMonth.map((t) => (
                <tr key={t.id}>
                  <td>{shortDate(t.tx_date)}</td><td>{t.category}</td><td className="muted">{t.description}</td>
                  <td className={`r ${t.type === 'income' ? 'pos' : 'neg'}`}>{t.type === 'income' ? '+' : '−'}{money(t.amount)}</td>
                  <td className="r"><button className="link danger" onClick={() => confirm('Delete this entry?') && remove(t.id)}>Delete</button></td>
                </tr>
              ))}</tbody>
            </table>
          </div>
        )}
      </section>
    </>
  );
}
