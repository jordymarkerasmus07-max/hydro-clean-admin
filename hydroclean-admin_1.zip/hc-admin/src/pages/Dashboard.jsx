import { Link } from 'react-router-dom';
import { money0, monthKey, shortDate, today, useTable } from '../lib/util';

export default function Dashboard() {
  const tx = useTable('transactions', { order: 'tx_date' });
  const leads = useTable('leads');
  const jobs = useTable('jobs', { order: 'scheduled_date', ascending: true });
  const quotes = useTable('quotes');

  const m = monthKey(today());
  const monthTx = tx.rows.filter((t) => monthKey(t.tx_date) === m);
  const income = monthTx.filter((t) => t.type === 'income').reduce((a, t) => a + +t.amount, 0);
  const expense = monthTx.filter((t) => t.type === 'expense').reduce((a, t) => a + +t.amount, 0);

  const due = leads.rows.filter((l) => l.next_follow_up && l.next_follow_up <= today() && !['won', 'lost', 'do_not_contact'].includes(l.status));
  const upcoming = jobs.rows.filter((j) => ['booked', 'in_progress'].includes(j.status)).slice(0, 6);
  const waiting = quotes.rows.filter((q) => q.status === 'sent');
  const owed = jobs.rows.filter((j) => j.status === 'done' && !j.balance_paid).reduce((a, j) => a + (+j.amount - +j.deposit_paid), 0);
  const pipeline = waiting.reduce((a, q) => a + +q.total, 0);
  const count = (s) => leads.rows.filter((l) => l.status === s).length;

  return (
    <>
      <header className="page-head"><h1>Dashboard</h1><div className="actions"><Link className="btn primary" to="/quotes/new">+ New quote</Link></div></header>

      <div className="stats">
        <Stat label="Income this month" value={money0(income)} />
        <Stat label="Expenses this month" value={money0(expense)} />
        <Stat label="Profit this month" value={money0(income - expense)} tone={income - expense >= 0 ? 'good' : 'bad'} />
        <Stat label="Owed to you" value={money0(owed)} hint="Finished jobs not fully paid" />
        <Stat label="Quotes waiting" value={money0(pipeline)} hint={`${waiting.length} sent, no answer yet`} />
      </div>

      <div className="grid2">
        <section className="card">
          <div className="card-head"><h3>Follow-ups due</h3><Link to="/leads?due=1">Open outreach →</Link></div>
          {due.length === 0 ? <p className="muted">Nothing due. Nice.</p> : (
            <ul className="list">{due.slice(0, 8).map((l) => (
              <li key={l.id}><b>{l.business}</b><span className="muted">{l.town} · due {shortDate(l.next_follow_up)}</span></li>
            ))}</ul>
          )}
        </section>

        <section className="card">
          <div className="card-head"><h3>Upcoming jobs</h3><Link to="/jobs">All jobs →</Link></div>
          {upcoming.length === 0 ? <p className="muted">No jobs booked yet.</p> : (
            <ul className="list">{upcoming.map((j) => (
              <li key={j.id}><b>{j.title}</b><span className="muted">{j.client_name} · {shortDate(j.scheduled_date)} · {money0(j.amount)}</span></li>
            ))}</ul>
          )}
        </section>

        <section className="card">
          <div className="card-head"><h3>Outreach pipeline</h3></div>
          <div className="funnel">
            {[['new', 'New'], ['contacted', 'Contacted'], ['replied', 'Replied'], ['quoted', 'Quoted'], ['won', 'Won']].map(([k, l]) => (
              <Link key={k} to={`/leads?status=${k}`} className="fstep"><b>{count(k)}</b><span>{l}</span></Link>
            ))}
          </div>
        </section>

        <section className="card">
          <div className="card-head"><h3>Quotes waiting for an answer</h3><Link to="/quotes">All quotes →</Link></div>
          {waiting.length === 0 ? <p className="muted">No open quotes.</p> : (
            <ul className="list">{waiting.slice(0, 6).map((q) => (
              <li key={q.id}><Link to={`/quotes/${q.id}`}><b>{q.number} · {q.client_name}</b></Link><span className="muted">{money0(q.total)} · {shortDate(q.quote_date)}</span></li>
            ))}</ul>
          )}
        </section>
      </div>
    </>
  );
}

function Stat({ label, value, hint, tone }) {
  return (
    <div className={`stat ${tone || ''}`}>
      <span>{label}</span><b>{value}</b>{hint && <small>{hint}</small>}
    </div>
  );
}
