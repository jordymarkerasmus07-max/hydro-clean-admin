import { useState } from 'react';
import { Link } from 'react-router-dom';
import { money, shortDate, useTable } from '../lib/util';

const ST = [['', 'All'], ['draft', 'Draft'], ['sent', 'Sent'], ['accepted', 'Accepted'], ['declined', 'Declined']];

export default function Quotes() {
  const { rows, loading } = useTable('quotes');
  const [st, setSt] = useState('');
  const list = rows.filter((r) => !st || r.status === st);
  const won = rows.filter((r) => r.status === 'accepted').length;
  const decided = rows.filter((r) => ['accepted', 'declined'].includes(r.status)).length;

  return (
    <>
      <header className="page-head">
        <h1>Quotes</h1>
        <div className="actions"><Link className="btn primary" to="/quotes/new">+ New quote</Link></div>
      </header>
      <div className="chips">
        {ST.map(([k, l]) => <button key={k} className={st === k ? 'on' : ''} onClick={() => setSt(k)}>{l} <i>{k ? rows.filter((r) => r.status === k).length : rows.length}</i></button>)}
        {decided > 0 && <span className="muted small" style={{ alignSelf: 'center' }}>Win rate: {Math.round((won / decided) * 100)}%</span>}
      </div>
      {loading ? <p className="muted">Loading…</p> : list.length === 0 ? (
        <div className="card empty"><h3>No quotes yet</h3><p className="muted">Build your first one. It uses your HydroClean quote layout and downloads as a PDF.</p></div>
      ) : (
        <div className="table-wrap card">
          <table className="tbl">
            <thead><tr><th>Quote</th><th>Client</th><th>Job</th><th>Date</th><th className="r">Total</th><th>Status</th></tr></thead>
            <tbody>
              {list.map((q) => (
                <tr key={q.id}>
                  <td><Link to={`/quotes/${q.id}`}><b>{q.number}</b></Link></td>
                  <td>{q.client_name}</td>
                  <td className="muted">{q.job_type}</td>
                  <td>{shortDate(q.quote_date)}</td>
                  <td className="r">{money(q.total)}</td>
                  <td><span className={`pill q-${q.status}`}>{q.status}</span></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </>
  );
}
