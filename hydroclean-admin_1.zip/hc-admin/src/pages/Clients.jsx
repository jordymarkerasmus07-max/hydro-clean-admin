import { useState } from 'react';
import { Link } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { money0, shortDate, telLink, useTable, waLink } from '../lib/util';

export default function Clients() {
  const { rows, loading, load } = useTable('clients', { order: 'name', ascending: true });
  const jobs = useTable('jobs');
  const [q, setQ] = useState('');
  const [edit, setEdit] = useState(null);
  const list = rows.filter((c) => !q || `${c.name} ${c.phone} ${c.email} ${c.address} ${c.area}`.toLowerCase().includes(q.toLowerCase()));
  const stats = (id) => {
    const js = jobs.rows.filter((j) => j.client_id === id);
    return { n: js.length, spent: js.filter((j) => j.status === 'done').reduce((a, j) => a + +j.amount, 0), last: js.map((j) => j.scheduled_date).filter(Boolean).sort().pop() };
  };

  return (
    <>
      <header className="page-head">
        <h1>Clients</h1>
        <div className="actions"><button className="btn primary" onClick={() => setEdit({ name: '', type: 'Residential' })}>+ Add client</button></div>
      </header>
      <div className="filters"><input placeholder="Search clients…" value={q} onChange={(e) => setQ(e.target.value)} /></div>
      {loading ? <p className="muted">Loading…</p> : list.length === 0 ? (
        <div className="card empty"><h3>No clients yet</h3><p className="muted">Clients are added automatically when a quote is accepted, or add past clients here so you can message them for repeat work.</p></div>
      ) : (
        <div className="table-wrap card">
          <table className="tbl">
            <thead><tr><th>Client</th><th>Area</th><th>Jobs</th><th className="r">Spent</th><th>Last job</th><th /></tr></thead>
            <tbody>
              {list.map((c) => {
                const st = stats(c.id);
                return (
                  <tr key={c.id}>
                    <td><button className="link" onClick={() => setEdit(c)}><b>{c.name}</b></button><div className="muted small">{c.type}{c.phone ? ` · ${c.phone}` : ''}</div></td>
                    <td>{c.area || '—'}</td>
                    <td>{st.n}</td>
                    <td className="r">{money0(st.spent)}</td>
                    <td>{shortDate(st.last)}</td>
                    <td className="r nowrap">
                      {waLink(c.phone) && <a className="btn sm wa" href={waLink(c.phone, `Hi ${c.name.split(' ')[0]}, `)} target="_blank" rel="noreferrer">WhatsApp</a>}
                      {c.phone && <a className="btn sm" href={telLink(c.phone)}>Call</a>}
                      <Link className="btn sm" to={`/quotes/new?client=${c.id}`}>Quote</Link>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
      {edit && <ClientEditor c={edit} onClose={() => setEdit(null)} onSaved={() => { setEdit(null); load(); }} />}
    </>
  );
}

function ClientEditor({ c, onClose, onSaved }) {
  const [f, setF] = useState(c);
  const [err, setErr] = useState('');
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });
  const save = async () => {
    if (!f.name) return setErr('Name is needed.');
    const { id, user_id, created_at, ...vals } = f;
    const res = id ? await supabase.from('clients').update(vals).eq('id', id) : await supabase.from('clients').insert(vals);
    if (res.error) return setErr(res.error.message);
    onSaved();
  };
  const del = async () => { if (!confirm('Delete this client? Their jobs and quotes stay.')) return; await supabase.from('clients').delete().eq('id', c.id); onSaved(); };
  return (
    <div className="drawer-bg" onClick={onClose}>
      <div className="drawer" onClick={(e) => e.stopPropagation()}>
        <h2>{c.id ? 'Edit client' : 'New client'}</h2>
        <label>Name<input value={f.name || ''} onChange={set('name')} /></label>
        <div className="row2">
          <label>Phone<input value={f.phone || ''} onChange={set('phone')} /></label>
          <label>Email<input value={f.email || ''} onChange={set('email')} /></label>
        </div>
        <label>Address<input value={f.address || ''} onChange={set('address')} /></label>
        <div className="row2">
          <label>Area<input value={f.area || ''} onChange={set('area')} placeholder="Knysna, Leisure Isle, Plett…" /></label>
          <label>Type<select value={f.type || 'Residential'} onChange={set('type')}><option>Residential</option><option>Holiday let</option><option>Business</option><option>Body corporate</option></select></label>
        </div>
        <label>Notes<textarea rows="3" value={f.notes || ''} onChange={set('notes')} /></label>
        {err && <p className="note bad">{err}</p>}
        <div className="drawer-actions">
          {c.id && <button className="btn danger" onClick={del}>Delete</button>}
          <span style={{ flex: 1 }} />
          <button className="btn" onClick={onClose}>Cancel</button>
          <button className="btn primary" onClick={save}>Save</button>
        </div>
      </div>
    </div>
  );
}
