import { useMemo, useRef, useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import * as XLSX from 'xlsx';
import { supabase } from '../lib/supabase';
import { LEAD_STATUSES } from '../lib/services';
import { addDays, downloadCSV, fill, shortDate, telLink, today, useSettings, useTable, waLink } from '../lib/util';

const STATUS_LABEL = Object.fromEntries(LEAD_STATUSES);
// Column names we recognise when importing a spreadsheet
const MAP = {
  business: ['business', 'business name', 'name', 'company', 'title'],
  segment: ['segment'],
  category: ['category', 'type', 'business type', 'search term'],
  town: ['town', 'city', 'area'],
  contact_name: ['contact', 'contact name', 'contact person'],
  phone: ['phone', 'phone number', 'telephone', 'tel', 'mobile'],
  email: ['email', 'email(s)', 'emails', 'e-mail'],
  website: ['website', 'site', 'url'],
  address: ['address', 'street address'],
  rating: ['rating', 'google rating'],
};

export default function Leads() {
  const { rows, loading, update, remove, load } = useTable('leads');
  const [settings] = useSettings();
  const [params, setParams] = useSearchParams();
  const [q, setQ] = useState('');
  const [seg, setSeg] = useState('');
  const [town, setTown] = useState('');
  const [edit, setEdit] = useState(null);
  const [importMsg, setImportMsg] = useState('');
  const fileRef = useRef();
  const nav = useNavigate();
  const status = params.get('status') || '';
  const dueOnly = params.get('due') === '1';

  const segments = useMemo(() => [...new Set(rows.map((r) => r.segment).filter(Boolean))].sort(), [rows]);
  const towns = useMemo(() => [...new Set(rows.map((r) => r.town).filter(Boolean))].sort(), [rows]);
  const list = rows.filter((l) =>
    (!status || l.status === status) &&
    (!seg || l.segment === seg) &&
    (!town || l.town === town) &&
    (!dueOnly || (l.next_follow_up && l.next_follow_up <= today() && !['won', 'lost', 'do_not_contact'].includes(l.status))) &&
    (!q || `${l.business} ${l.category} ${l.email} ${l.phone} ${l.notes}`.toLowerCase().includes(q.toLowerCase()))
  );
  const counts = Object.fromEntries(LEAD_STATUSES.map(([k]) => [k, rows.filter((r) => r.status === k).length]));

  const vals = (l) => ({ business: l.business, town: l.town || 'the Garden Route', name: l.contact_name || '' });
  const markContacted = (l) =>
    update(l.id, {
      status: l.status === 'new' ? 'contacted' : l.status,
      last_contacted: new Date().toISOString(),
      next_follow_up: addDays(today(), 4),
      contact_count: (l.contact_count || 0) + 1,
    });

  async function onImport(e) {
    const f = e.target.files[0];
    if (!f) return;
    setImportMsg('Reading file…');
    const wb = XLSX.read(await f.arrayBuffer());
    const seen = new Set(rows.map((r) => (r.business + '|' + (r.phone || '')).toLowerCase()));
    const out = [];
    for (const sheetName of wb.SheetNames) {
      if (/^all$/i.test(sheetName) && wb.SheetNames.length > 1) continue; // avoid double-importing the "All" tab
      const data = XLSX.utils.sheet_to_json(wb.Sheets[sheetName], { defval: '' });
      for (const raw of data) {
        const r = Object.fromEntries(Object.entries(raw).map(([k, v]) => [k.trim().toLowerCase(), String(v).trim()]));
        const lead = {};
        for (const [field, names] of Object.entries(MAP)) {
          const k = names.find((n) => r[n]);
          if (k) lead[field] = r[k];
        }
        if (!lead.business) continue;
        if (!lead.segment && wb.SheetNames.length > 1) lead.segment = sheetName;
        if (lead.email) lead.email = lead.email.split(/[;, ]+/)[0];
        const key = (lead.business + '|' + (lead.phone || '')).toLowerCase();
        if (seen.has(key)) continue;
        seen.add(key);
        out.push(lead);
      }
    }
    for (let i = 0; i < out.length; i += 500) {
      const { error } = await supabase.from('leads').insert(out.slice(i, i + 500));
      if (error) { setImportMsg('Import failed: ' + error.message); return; }
    }
    setImportMsg(`Imported ${out.length} new leads (duplicates skipped).`);
    e.target.value = '';
    load();
  }

  const setFilter = (k, v) => { const p = new URLSearchParams(params); v ? p.set(k, v) : p.delete(k); setParams(p); };

  return (
    <>
      <header className="page-head">
        <h1>Outreach</h1>
        <div className="actions">
          <input ref={fileRef} type="file" accept=".xlsx,.xls,.csv" hidden onChange={onImport} />
          <button className="btn" onClick={() => fileRef.current.click()}>Import spreadsheet</button>
          <button className="btn" onClick={() => downloadCSV('hydroclean-leads.csv', list)}>Export</button>
          <button className="btn primary" onClick={() => setEdit({ business: '', status: 'new' })}>+ Add lead</button>
        </div>
      </header>
      {importMsg && <p className="note">{importMsg}</p>}

      <div className="chips">
        <button className={!status && !dueOnly ? 'on' : ''} onClick={() => setParams({})}>All <i>{rows.length}</i></button>
        <button className={dueOnly ? 'on' : ''} onClick={() => setParams({ due: '1' })}>Follow-up due</button>
        {LEAD_STATUSES.map(([k, l]) => (
          <button key={k} className={status === k ? 'on' : ''} onClick={() => setFilter('status', status === k ? '' : k)}>{l} <i>{counts[k]}</i></button>
        ))}
      </div>
      <div className="filters">
        <input placeholder="Search business, email, notes…" value={q} onChange={(e) => setQ(e.target.value)} />
        <select value={seg} onChange={(e) => setSeg(e.target.value)}><option value="">All segments</option>{segments.map((s) => <option key={s}>{s}</option>)}</select>
        <select value={town} onChange={(e) => setTown(e.target.value)}><option value="">All towns</option>{towns.map((s) => <option key={s}>{s}</option>)}</select>
      </div>

      {loading ? <p className="muted">Loading…</p> : list.length === 0 ? (
        <div className="card empty"><h3>No leads here yet</h3><p className="muted">Import the spreadsheet from your scraper (Excel or CSV). Columns like Business name, Phone, Email, Website, Town and Category are picked up automatically.</p></div>
      ) : (
        <div className="lead-list">
          {list.map((l) => {
            const wa = settings && waLink(l.phone, fill(settings.wa_outreach, vals(l)));
            const mail = settings && l.email && `mailto:${l.email}?subject=${encodeURIComponent(fill(settings.email_subject, vals(l)))}&body=${encodeURIComponent(fill(settings.email_outreach, vals(l)))}`;
            const blocked = l.status === 'do_not_contact';
            return (
              <div className="lead" key={l.id}>
                <div className="lead-main" onClick={() => setEdit(l)}>
                  <b>{l.business}</b>
                  <span className="muted">{[l.category, l.town, l.rating && `★ ${l.rating}`].filter(Boolean).join(' · ')}</span>
                  {l.notes && <span className="lead-note">{l.notes}</span>}
                </div>
                <div className="lead-meta">
                  <select className={`pill s-${l.status}`} value={l.status} onChange={(e) => update(l.id, { status: e.target.value })}>
                    {LEAD_STATUSES.map(([k, lab]) => <option key={k} value={k}>{lab}</option>)}
                  </select>
                  <span className="muted small">{l.last_contacted ? `Last: ${shortDate(l.last_contacted)}` : 'Not contacted'}{l.next_follow_up ? ` · Next: ${shortDate(l.next_follow_up)}` : ''}</span>
                </div>
                <div className="lead-actions">
                  {wa && !blocked ? <a className="btn wa" href={wa} target="_blank" rel="noreferrer" onClick={() => markContacted(l)}>WhatsApp</a> : <span className="btn ghost disabled">WhatsApp</span>}
                  {l.phone && !blocked ? <a className="btn" href={telLink(l.phone)} onClick={() => markContacted(l)}>Call</a> : <span className="btn ghost disabled">Call</span>}
                  {mail && !blocked ? <a className="btn" href={mail} onClick={() => markContacted(l)}>Email</a> : <span className="btn ghost disabled">Email</span>}
                  <button className="btn" onClick={() => nav(`/quotes/new?lead=${l.id}`)}>Quote</button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {edit && <LeadEditor lead={edit} onClose={() => setEdit(null)} onSaved={() => { setEdit(null); load(); }} onDelete={async () => { await remove(edit.id); setEdit(null); }} />}
    </>
  );
}

function LeadEditor({ lead, onClose, onSaved, onDelete }) {
  const [f, setF] = useState(lead);
  const [err, setErr] = useState('');
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });
  const save = async () => {
    if (!f.business) return setErr('Business name is needed.');
    const { id, user_id, created_at, ...vals } = f;
    for (const k of Object.keys(vals)) if (vals[k] === '') vals[k] = null;
    vals.business = f.business;
    const res = id ? await supabase.from('leads').update(vals).eq('id', id) : await supabase.from('leads').insert(vals);
    if (res.error) return setErr(res.error.message);
    onSaved();
  };
  return (
    <div className="drawer-bg" onClick={onClose}>
      <div className="drawer" onClick={(e) => e.stopPropagation()}>
        <h2>{lead.id ? 'Edit lead' : 'New lead'}</h2>
        <label>Business<input value={f.business || ''} onChange={set('business')} /></label>
        <div className="row2">
          <label>Segment<input value={f.segment || ''} onChange={set('segment')} placeholder="Property / Hospitality / Commercial" /></label>
          <label>Category<input value={f.category || ''} onChange={set('category')} /></label>
        </div>
        <div className="row2">
          <label>Town<input value={f.town || ''} onChange={set('town')} /></label>
          <label>Contact name<input value={f.contact_name || ''} onChange={set('contact_name')} /></label>
        </div>
        <div className="row2">
          <label>Phone<input value={f.phone || ''} onChange={set('phone')} /></label>
          <label>Email<input value={f.email || ''} onChange={set('email')} /></label>
        </div>
        <label>Website<input value={f.website || ''} onChange={set('website')} /></label>
        <div className="row2">
          <label>Status<select value={f.status} onChange={set('status')}>{LEAD_STATUSES.map(([k, l]) => <option key={k} value={k}>{l}</option>)}</select></label>
          <label>Next follow-up<input type="date" value={f.next_follow_up || ''} onChange={set('next_follow_up')} /></label>
        </div>
        <label>Notes<textarea rows="4" value={f.notes || ''} onChange={set('notes')} placeholder="Who you spoke to, what they need, best time to call…" /></label>
        {f.website && <p><a href={f.website.startsWith('http') ? f.website : 'https://' + f.website} target="_blank" rel="noreferrer">Open website ↗</a></p>}
        {err && <p className="note bad">{err}</p>}
        <div className="drawer-actions">
          {lead.id && <button className="btn danger" onClick={() => confirm('Delete this lead?') && onDelete()}>Delete</button>}
          <span style={{ flex: 1 }} />
          <button className="btn" onClick={onClose}>Cancel</button>
          <button className="btn primary" onClick={save}>Save</button>
        </div>
      </div>
    </div>
  );
}
