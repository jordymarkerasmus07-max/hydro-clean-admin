import { useState } from 'react';
import { supabase } from '../lib/supabase';
import { longDate, money, shortDate, today, useSettings, useTable, waLink } from '../lib/util';

const STATUSES = [['booked', 'Booked'], ['in_progress', 'In progress'], ['done', 'Done'], ['cancelled', 'Cancelled']];

export default function Jobs() {
  const { rows, loading, update, load } = useTable('jobs', { order: 'scheduled_date', ascending: true });
  const [settings] = useSettings();
  const [tab, setTab] = useState('open');
  const [edit, setEdit] = useState(null);
  const [msg, setMsg] = useState('');

  const open = rows.filter((j) => ['booked', 'in_progress'].includes(j.status));
  const done = rows.filter((j) => j.status === 'done').reverse();
  const list = tab === 'open' ? open : tab === 'done' ? done : rows.filter((j) => j.status === 'cancelled');
  const unscheduled = open.filter((j) => !j.scheduled_date).length;

  async function addPayment(j, kind) {
    const owed = +j.amount - +j.deposit_paid;
    const def = kind === 'deposit' ? Math.round(+j.amount / 2) : owed;
    const v = prompt(kind === 'deposit' ? 'Deposit received (R):' : 'Balance received (R):', String(def));
    if (v === null) return;
    const amt = +v;
    if (!(amt > 0)) return;
    const { error } = await supabase.from('transactions').insert({
      type: 'income', category: kind === 'deposit' ? 'Deposit' : 'Job payment',
      description: `${j.title} – ${j.client_name || ''}`, amount: amt, job_id: j.id, tx_date: today(),
    });
    if (error) return setMsg(error.message);
    const paid = +j.deposit_paid + amt;
    await update(j.id, { deposit_paid: paid, balance_paid: paid >= +j.amount });
    setMsg(`${money(amt)} recorded in Finances.`);
  }

  const reviewText = (j) => `Hi ${(j.client_name || '').split(' ')[0]}, thanks again for choosing HydroClean! If you're happy with the job, would you mind leaving us a quick Google review? It really helps a small local business.${settings?.review_link ? '\n\n' + settings.review_link : ''}`;
  const reminderText = (j) => `Hi ${(j.client_name || '').split(' ')[0]}, just confirming HydroClean is booked for ${j.title.toLowerCase()} on ${longDate(j.scheduled_date)}. Please make sure we have access and an outside tap. See you then!`;

  return (
    <>
      <header className="page-head">
        <h1>Jobs</h1>
        <div className="actions"><button className="btn primary" onClick={() => setEdit({ title: '', status: 'booked', amount: 0, deposit_paid: 0 })}>+ Add job</button></div>
      </header>
      {msg && <p className="note">{msg}</p>}
      <div className="chips">
        <button className={tab === 'open' ? 'on' : ''} onClick={() => setTab('open')}>Upcoming <i>{open.length}</i></button>
        <button className={tab === 'done' ? 'on' : ''} onClick={() => setTab('done')}>Done <i>{done.length}</i></button>
        <button className={tab === 'cancelled' ? 'on' : ''} onClick={() => setTab('cancelled')}>Cancelled</button>
        {tab === 'open' && unscheduled > 0 && <span className="muted small" style={{ alignSelf: 'center' }}>{unscheduled} still need a date</span>}
      </div>

      {loading ? <p className="muted">Loading…</p> : list.length === 0 ? (
        <div className="card empty"><h3>No jobs here</h3><p className="muted">When a quote is accepted, tap “Accepted → book job” and it lands here.</p></div>
      ) : (
        <div className="job-list">
          {list.map((j) => {
            const owed = Math.max(0, +j.amount - +j.deposit_paid);
            const late = j.scheduled_date && j.scheduled_date < today() && j.status !== 'done';
            return (
              <div className="job card" key={j.id}>
                <div className="job-date"><b>{j.scheduled_date ? new Date(j.scheduled_date).getDate() : '?'}</b><span>{j.scheduled_date ? new Date(j.scheduled_date).toLocaleDateString('en-ZA', { month: 'short' }) : 'No date'}</span></div>
                <div className="job-main" onClick={() => setEdit(j)}>
                  <b>{j.title}</b>
                  <span className="muted">{[j.client_name, j.address].filter(Boolean).join(' · ')}</span>
                  <span className="small">{money(j.amount)} · paid {money(j.deposit_paid)}{owed > 0 ? <b className="owed"> · owes {money(owed)}</b> : <b className="paid"> · paid in full</b>}{late && <b className="owed"> · date passed</b>}</span>
                </div>
                <div className="job-actions">
                  <select className={`pill j-${j.status}`} value={j.status} onChange={(e) => update(j.id, { status: e.target.value })}>
                    {STATUSES.map(([k, l]) => <option key={k} value={k}>{l}</option>)}
                  </select>
                  {+j.deposit_paid === 0 && j.status !== 'done' && <button className="btn" onClick={() => addPayment(j, 'deposit')}>Deposit received</button>}
                  {owed > 0 && <button className="btn" onClick={() => addPayment(j, 'balance')}>Payment received</button>}
                  {j.status !== 'done' && j.scheduled_date && waLink(j.client_phone) && <a className="btn wa" href={waLink(j.client_phone, reminderText(j))} target="_blank" rel="noreferrer">Remind client</a>}
                  {j.status === 'done' && waLink(j.client_phone) && (
                    <a className={`btn ${j.review_requested ? 'ghost' : 'wa'}`} href={waLink(j.client_phone, reviewText(j))} target="_blank" rel="noreferrer" onClick={() => update(j.id, { review_requested: true })}>
                      {j.review_requested ? 'Review asked ✓' : 'Ask for review'}
                    </a>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
      {edit && <JobEditor job={edit} onClose={() => setEdit(null)} onSaved={() => { setEdit(null); load(); }} />}
    </>
  );
}

function JobEditor({ job, onClose, onSaved }) {
  const [f, setF] = useState(job);
  const [err, setErr] = useState('');
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });
  const save = async () => {
    if (!f.title) return setErr('Give the job a title.');
    const { id, user_id, created_at, ...vals } = f;
    for (const k of Object.keys(vals)) if (vals[k] === '') vals[k] = null;
    vals.amount = +f.amount || 0; vals.deposit_paid = +f.deposit_paid || 0;
    const res = id ? await supabase.from('jobs').update(vals).eq('id', id) : await supabase.from('jobs').insert(vals);
    if (res.error) return setErr(res.error.message);
    onSaved();
  };
  const del = async () => { if (!confirm('Delete this job?')) return; await supabase.from('jobs').delete().eq('id', job.id); onSaved(); };
  return (
    <div className="drawer-bg" onClick={onClose}>
      <div className="drawer" onClick={(e) => e.stopPropagation()}>
        <h2>{job.id ? 'Edit job' : 'New job'}</h2>
        <label>Job<input value={f.title || ''} onChange={set('title')} placeholder="e.g. Roof soft wash" /></label>
        <div className="row2">
          <label>Client<input value={f.client_name || ''} onChange={set('client_name')} /></label>
          <label>Client phone<input value={f.client_phone || ''} onChange={set('client_phone')} /></label>
        </div>
        <label>Address<input value={f.address || ''} onChange={set('address')} /></label>
        <div className="row2">
          <label>Date<input type="date" value={f.scheduled_date || ''} onChange={set('scheduled_date')} /></label>
          <label>Status<select value={f.status} onChange={set('status')}>{STATUSES.map(([k, l]) => <option key={k} value={k}>{l}</option>)}</select></label>
        </div>
        <div className="row2">
          <label>Job value (R)<input type="number" value={f.amount} onChange={set('amount')} /></label>
          <label>Paid so far (R)<input type="number" value={f.deposit_paid} onChange={set('deposit_paid')} /></label>
        </div>
        <label>Notes<textarea rows="3" value={f.notes || ''} onChange={set('notes')} placeholder="Access, gate code, water point, special care…" /></label>
        <p className="muted small">Tip: use “Deposit received” / “Payment received” on the job card so the money also lands in Finances.</p>
        {err && <p className="note bad">{err}</p>}
        <div className="drawer-actions">
          {job.id && <button className="btn danger" onClick={del}>Delete</button>}
          <span style={{ flex: 1 }} />
          <button className="btn" onClick={onClose}>Cancel</button>
          <button className="btn primary" onClick={save}>Save</button>
        </div>
        {job.id && <p className="muted small">Booked {shortDate(job.created_at)}</p>}
      </div>
    </div>
  );
}
