import { useEffect, useRef, useState } from 'react';
import { useNavigate, useParams, useSearchParams } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { SERVICES } from '../lib/services';
import { getSettings, longDate, money, today, waLink } from '../lib/util';

const blankItem = () => ({ title: '', areas: '', scope: '', qty: 1, price: '', note: '' });
const calc = (q) => {
  const sub = (q.items || []).reduce((a, i) => a + (+i.qty || 0) * (+i.price || 0), 0);
  const vat = sub * ((+q.vat_rate || 0) / 100);
  return { sub, vat, total: sub + vat };
};

export default function QuoteEdit({ printOnly }) {
  const { id } = useParams();
  const [params] = useSearchParams();
  const nav = useNavigate();
  const [s, setS] = useState(null);
  const [q, setQ] = useState(null);
  const [clients, setClients] = useState([]);
  const [msg, setMsg] = useState('');
  const isNew = id === 'new';

  useEffect(() => {
    (async () => {
      const st = await getSettings();
      setS(st);
      const { data: cl } = await supabase.from('clients').select('*').order('name');
      setClients(cl || []);
      if (!isNew) {
        const { data } = await supabase.from('quotes').select('*').eq('id', id).single();
        setQ({ ...data, items: (data.items || []).map((i) => ({ ...i, scope: Array.isArray(i.scope) ? i.scope.join('\n') : i.scope || '' })) });
        if (printOnly) setTimeout(() => window.print(), 600);
        return;
      }
      const base = {
        number: '', client_name: '', client_address: '', client_phone: '', client_email: '',
        job_type: '', salesperson: st.salesperson, payment_terms: st.payment_terms,
        quote_date: today(), valid_days: 30, vat_rate: st.vat_rate || 0, items: [blankItem()],
        terms: st.default_terms, note: "Client's water supply will be used for the duration of the service.", status: 'draft',
      };
      const leadId = params.get('lead');
      const clientId = params.get('client');
      if (leadId) {
        const { data: l } = await supabase.from('leads').select('*').eq('id', leadId).single();
        if (l) Object.assign(base, { lead_id: l.id, client_name: l.business, client_address: [l.address, l.town].filter(Boolean).join(', '), client_phone: l.phone || '', client_email: l.email || '' });
      }
      if (clientId) {
        const c = (cl || []).find((x) => x.id === clientId);
        if (c) Object.assign(base, { client_id: c.id, client_name: c.name, client_address: [c.address, c.area].filter(Boolean).join(', '), client_phone: c.phone || '', client_email: c.email || '' });
      }
      setQ(base);
    })();
  }, [id]);

  if (!q || !s) return <p className="muted">Loading…</p>;
  const { sub, vat, total } = calc(q);
  const set = (k) => (e) => setQ({ ...q, [k]: e.target.value });
  const setItem = (i, k, v) => setQ({ ...q, items: q.items.map((it, j) => (j === i ? { ...it, [k]: v } : it)) });
  const addPreset = (title) => {
    const p = SERVICES.find((x) => x.title === title);
    const item = p ? { ...blankItem(), title: p.title, areas: p.areas, scope: p.scope.join('\n') } : blankItem();
    const items = q.items.length === 1 && !q.items[0].title ? [item] : [...q.items, item];
    setQ({ ...q, items, job_type: q.job_type || item.title });
  };
  const pickClient = (cid) => {
    const c = clients.find((x) => x.id === cid);
    if (!c) return setQ({ ...q, client_id: null });
    setQ({ ...q, client_id: c.id, client_name: c.name, client_address: [c.address, c.area].filter(Boolean).join(', '), client_phone: c.phone || '', client_email: c.email || '' });
  };

  async function save(extra = {}) {
    setMsg('');
    const rec = { ...q, ...extra, total };
    rec.items = q.items.map((i) => ({ ...i, scope: String(i.scope || '').split('\n').map((x) => x.trim()).filter(Boolean), qty: +i.qty || 1, price: +i.price || 0 }));
    delete rec.id; delete rec.user_id; delete rec.created_at;
    if (isNew) {
      rec.number = `${s.quote_prefix || 'Q'}${s.next_quote_no}`;
      const { data, error } = await supabase.from('quotes').insert(rec).select().single();
      if (error) return setMsg(error.message);
      await supabase.from('settings').update({ next_quote_no: (s.next_quote_no || 0) + 1 }).eq('user_id', s.user_id);
      if (rec.lead_id) await supabase.from('leads').update({ status: 'quoted' }).eq('id', rec.lead_id);
      nav(`/quotes/${data.id}`, { replace: true });
      return data;
    }
    const { error } = await supabase.from('quotes').update(rec).eq('id', id);
    if (error) return setMsg(error.message);
    setQ({ ...q, ...extra });
    setMsg('Saved.');
    return { id, ...rec };
  }

  async function accept() {
    const saved = await save({ status: 'accepted' });
    if (!saved) return;
    let clientId = q.client_id;
    if (!clientId) {
      const { data: c, error } = await supabase.from('clients')
        .insert({ name: q.client_name, phone: q.client_phone, email: q.client_email, address: q.client_address, type: q.lead_id ? 'Business' : 'Residential' })
        .select().single();
      if (error) return setMsg(error.message);
      clientId = c.id;
      await supabase.from('quotes').update({ client_id: clientId }).eq('id', saved.id);
    }
    const { error } = await supabase.from('jobs').insert({
      client_id: clientId, quote_id: saved.id, title: q.job_type || q.items[0]?.title || 'Cleaning job',
      client_name: q.client_name, client_phone: q.client_phone, address: q.client_address, amount: total, status: 'booked',
    });
    if (error) return setMsg(error.message);
    if (q.lead_id) await supabase.from('leads').update({ status: 'won' }).eq('id', q.lead_id);
    nav('/jobs');
  }

  const doc = <QuoteDoc q={q} s={s} sub={sub} vat={vat} total={total} />;
  if (printOnly) return <div className="print-only-page">{doc}</div>;

  const first = (q.client_name || '').split(' ')[0];
  const waText = `Hi ${first}, thank you for having us out. Please find your HydroClean quote (${q.number || 'attached'}) for ${q.job_type || 'the cleaning'} attached. Any questions, just shout. We'd love to get you booked in.`;
  const wa = waLink(q.client_phone, waText);

  return (
    <>
      <header className="page-head no-print">
        <h1>{isNew ? 'New quote' : `Quote ${q.number}`}</h1>
        <div className="actions">
          {!isNew && <span className={`pill q-${q.status}`}>{q.status}</span>}
          <button className="btn" onClick={() => save()}>Save</button>
          {!isNew && <button className="btn" onClick={() => window.print()}>Download PDF</button>}
          {!isNew && wa && <a className="btn wa" href={wa} target="_blank" rel="noreferrer" onClick={() => q.status === 'draft' && save({ status: 'sent' })}>WhatsApp client</a>}
          {!isNew && q.status !== 'accepted' && <button className="btn primary" onClick={accept}>Accepted → book job</button>}
          {!isNew && q.status !== 'declined' && q.status !== 'accepted' && <button className="btn ghost" onClick={() => save({ status: 'declined' })}>Declined</button>}
        </div>
      </header>
      {msg && <p className="note no-print">{msg}</p>}
      {!isNew && <p className="muted small no-print">PDF tip: in the print window choose “Save as PDF”, then attach it in WhatsApp.</p>}

      <div className="quote-layout">
        <div className="quote-form no-print">
          <section className="card">
            <h3>Client</h3>
            {clients.length > 0 && (
              <label>Existing client<select value={q.client_id || ''} onChange={(e) => pickClient(e.target.value)}><option value="">— New / not in list —</option>{clients.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}</select></label>
            )}
            <label>Name<input value={q.client_name || ''} onChange={set('client_name')} /></label>
            <label>Address<input value={q.client_address || ''} onChange={set('client_address')} /></label>
            <div className="row2">
              <label>Phone<input value={q.client_phone || ''} onChange={set('client_phone')} /></label>
              <label>Email<input value={q.client_email || ''} onChange={set('client_email')} /></label>
            </div>
          </section>

          <section className="card">
            <h3>Details</h3>
            <label>Job type<input value={q.job_type || ''} onChange={set('job_type')} placeholder="e.g. High Pressure Paving & Tile Cleaning" /></label>
            <div className="row2">
              <label>Date<input type="date" value={q.quote_date || ''} onChange={set('quote_date')} /></label>
              <label>Valid (days)<input type="number" value={q.valid_days} onChange={set('valid_days')} /></label>
            </div>
            <div className="row2">
              <label>Salesperson<input value={q.salesperson || ''} onChange={set('salesperson')} /></label>
              <label>VAT %<input type="number" value={q.vat_rate} onChange={set('vat_rate')} /></label>
            </div>
            <label>Payment terms<input value={q.payment_terms || ''} onChange={set('payment_terms')} /></label>
          </section>

          <section className="card">
            <div className="card-head"><h3>Services</h3>
              <select value="" onChange={(e) => addPreset(e.target.value)}>
                <option value="">+ Add service…</option>
                {SERVICES.map((x) => <option key={x.title}>{x.title}</option>)}
                <option value="__blank">Blank line</option>
              </select>
            </div>
            {q.items.map((it, i) => (
              <div className="item" key={i}>
                <label>Service<input value={it.title} onChange={(e) => setItem(i, 'title', e.target.value)} /></label>
                <label>Areas included<input value={it.areas} onChange={(e) => setItem(i, 'areas', e.target.value)} /></label>
                <label>Scope of works <small className="muted">(one step per line; “Step — detail”)</small><textarea rows="4" value={it.scope} onChange={(e) => setItem(i, 'scope', e.target.value)} /></label>
                <div className="row3">
                  <label>Qty<input type="number" value={it.qty} onChange={(e) => setItem(i, 'qty', e.target.value)} /></label>
                  <label>Price (R)<input type="number" value={it.price} onChange={(e) => setItem(i, 'price', e.target.value)} /></label>
                  <label>Line total<input disabled value={money((+it.qty || 0) * (+it.price || 0))} /></label>
                </div>
                {q.items.length > 1 && <button className="link danger" onClick={() => setQ({ ...q, items: q.items.filter((_, j) => j !== i) })}>Remove service</button>}
              </div>
            ))}
            <label>Note (green line under services)<input value={q.note || ''} onChange={set('note')} /></label>
          </section>

          <section className="card">
            <h3>Terms</h3>
            <label><small className="muted">One per line</small><textarea rows="5" value={q.terms || ''} onChange={set('terms')} /></label>
          </section>
          <button className="btn primary block" onClick={() => save()}>{isNew ? 'Save quote' : 'Save changes'}</button>
        </div>

        <FitPreview>{doc}</FitPreview>
      </div>
    </>
  );
}

export function QuoteDoc({ q, s, sub, vat, total }) {
  const terms = String(q.terms || '').split('\n').map((x) => x.trim()).filter(Boolean);
  return (
    <div className="qdoc">
      <header className="qd-head">
        <img src="/logo.png" alt="Hydro Clean" />
        <div className="qd-co"><span className="tag">{s.tagline}</span><br />{s.address}<br />{s.phone} | {s.email}</div>
      </header>
      <div className="qd-top">
        <h1>QUOTE</h1>
        <div className="qd-meta">QUOTE # <b>{q.number || 'DRAFT'}</b><br />DATE <b>{longDate(q.quote_date)}</b><br />VALID <b>{q.valid_days} Days</b></div>
      </div>
      <div className="qd-box"><div className="qd-bh">QUOTE TO</div><div className="qd-to"><b>{q.client_name || 'Client name'}</b>{q.client_address && <><br />{q.client_address}</>}</div></div>
      <table className="qd-info"><thead><tr><th>SALESPERSON</th><th>JOB TYPE</th><th>PAYMENT TERMS</th></tr></thead>
        <tbody><tr><td>{q.salesperson}</td><td>{q.job_type}</td><td>{q.payment_terms}</td></tr></tbody></table>
      <table className="qd-items"><thead><tr><th>QTY</th><th>DESCRIPTION &amp; SERVICES INCLUDED</th><th className="r">AMOUNT</th></tr></thead>
        <tbody>
          {q.items.map((it, i) => {
            const steps = String(it.scope || '').split('\n').map((x) => x.trim()).filter(Boolean);
            return (
              <tr key={i}>
                <td className="q">{it.qty}</td>
                <td>
                  <b>{it.title || 'Service'}</b>
                  {it.areas && <div className="sc"><b>Areas Included:</b> {it.areas}</div>}
                  {steps.length > 0 && <div className="sc"><b>Scope of Works:</b><ol>{steps.map((st, j) => {
                    const [a, ...b] = st.split(' — ');
                    return <li key={j}>{b.length ? <><b>{a}</b> — {b.join(' — ')}</> : st}</li>;
                  })}</ol></div>}
                  {i === q.items.length - 1 && q.note && <div className="qd-note">Note: {q.note}</div>}
                </td>
                <td className="a">{money((+it.qty || 0) * (+it.price || 0))}</td>
              </tr>
            );
          })}
        </tbody></table>
      <div className="qd-tot">
        <div><span>Subtotal</span><span>{money(sub)}</span></div>
        <div><span>VAT ({+q.vat_rate || 0}%)</span><span>{money(vat)}</span></div>
        <div className="big"><span>TOTAL</span><span>{money(total)}</span></div>
      </div>
      {terms.length > 0 && <><h3>Terms &amp; Conditions</h3><ul className="qd-terms">{terms.map((t, i) => <li key={i}>{t}</li>)}</ul></>}
      {s.bank_details && <><h3>Banking Details</h3><p className="qd-bank">{s.bank_details}</p></>}
      <div className="qd-sign"><div>Acceptance Signature:<small>(Sign and return to confirm acceptance of this quote)</small></div><div>Date:</div></div>
      <footer className="qd-foot"><span>Prepared by: <b>{q.salesperson}</b> · {s.business_name}</span><span className="ty">Thank you for your business!</span></footer>
    </div>
  );
}

// Scales the A4 preview down to fit whatever space is available (print is always full size)
function FitPreview({ children }) {
  const ref = useRef();
  const [z, setZ] = useState(1);
  useEffect(() => {
    const el = ref.current;
    const ro = new ResizeObserver(() => setZ(Math.min(1, (el.clientWidth - 36) / 794)));
    ro.observe(el);
    return () => ro.disconnect();
  }, []);
  return <div className="quote-preview" ref={ref} style={{ '--z': z }}>{children}</div>;
}
