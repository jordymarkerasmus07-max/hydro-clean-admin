import { useEffect, useState } from 'react';
import { NavLink, Navigate, Route, Routes, useLocation } from 'react-router-dom';
import { configured, supabase } from './lib/supabase';
import Login, { SetPassword } from './pages/Login';
import Dashboard from './pages/Dashboard';
import Leads from './pages/Leads';
import Quotes from './pages/Quotes';
import QuoteEdit from './pages/QuoteEdit';
import Clients from './pages/Clients';
import Jobs from './pages/Jobs';
import Finances from './pages/Finances';
import Settings from './pages/Settings';

const NAV = [
  ['/', 'Dashboard', 'M3 12l9-9 9 9M5 10v10h14V10'],
  ['/leads', 'Outreach', 'M4 4h16v12H5l-1 4z'],
  ['/quotes', 'Quotes', 'M6 2h9l5 5v15H6zM14 2v6h6M9 13h6M9 17h6'],
  ['/jobs', 'Jobs', 'M3 5h18v16H3zM3 10h18M8 2v6M16 2v6'],
  ['/clients', 'Clients', 'M16 11a4 4 0 1 0-8 0M3 21a9 9 0 0 1 18 0'],
  ['/finances', 'Finances', 'M3 21h18M6 17V9M11 17V5M16 17v-6M21 17V8'],
  ['/settings', 'Settings', 'M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6zM4 12h2M18 12h2M12 4v2M12 18v2'],
];

export default function App() {
  const [session, setSession] = useState(undefined);
  const [recovery, setRecovery] = useState(false);
  const loc = useLocation();

  useEffect(() => {
    if (!configured) return;
    supabase.auth.getSession().then(({ data }) => setSession(data.session));
    const { data } = supabase.auth.onAuthStateChange((event, s) => {
      if (event === 'PASSWORD_RECOVERY') setRecovery(true);
      setSession(s);
    });
    return () => data.subscription.unsubscribe();
  }, []);

  if (!configured)
    return (
      <div className="center-screen"><div className="card narrow">
        <img src="/logo.png" alt="Hydro Clean" className="login-logo" />
        <h2>Almost there</h2>
        <p className="muted">Add your Supabase URL and key to the <code>.env</code> file (see SETUP.md), then restart.</p>
      </div></div>
    );
  if (session === undefined) return <div className="center-screen muted">Loading…</div>;
  if (recovery) return <SetPassword onDone={() => setRecovery(false)} />;
  if (!session) return <Login />;
  if (loc.pathname.match(/^\/quotes\/[^/]+\/print$/)) return <Routes><Route path="/quotes/:id/print" element={<QuoteEdit printOnly />} /></Routes>;

  return (
    <div className="shell">
      <aside className="side">
        <div className="brand"><img src="/logo.png" alt="Hydro Clean" /></div>
        <nav>
          {NAV.map(([to, label, d]) => (
            <NavLink key={to} to={to} end={to === '/'}>
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d={d} /></svg>
              <span>{label}</span>
            </NavLink>
          ))}
        </nav>
        <button className="link signout" onClick={() => supabase.auth.signOut()}>Sign out</button>
      </aside>
      <main className="main">
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/leads" element={<Leads />} />
          <Route path="/quotes" element={<Quotes />} />
          <Route path="/quotes/:id" element={<QuoteEdit />} />
          <Route path="/jobs" element={<Jobs />} />
          <Route path="/clients" element={<Clients />} />
          <Route path="/finances" element={<Finances />} />
          <Route path="/settings" element={<Settings />} />
          <Route path="*" element={<Navigate to="/" />} />
        </Routes>
      </main>
    </div>
  );
}
