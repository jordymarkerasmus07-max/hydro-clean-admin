# HydroClean Admin

Private admin for HydroClean: outreach, quotes, jobs, clients, finances.

- **Setup:** see [SETUP.md](SETUP.md)
- **Run locally:** `npm install` then `npm run dev`
- **Build:** `npm run build` (output in `dist/`)
- **Stack:** React + Vite (front end), Supabase (database + login, with Row Level Security)
- **Database schema:** `supabase/schema.sql`
