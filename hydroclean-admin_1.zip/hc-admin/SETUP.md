# HydroClean Admin – setup guide

This is your private admin at **admin.hydro-clean.co.za**: outreach, quotes, jobs, clients and finances behind your own login.

**Total time:** about 30–45 minutes. **Cost:** R0. Supabase and Vercel both have free plans that are plenty for one business.

You'll set up three things:
1. **Supabase**: your database and login (stores everything securely).
2. **Vercel**: hosts the app.
3. **Wix DNS**: points admin.hydro-clean.co.za at it.

> Easiest way: open this folder in VS Code and ask Claude Code: *"Follow SETUP.md with me step by step."* It can run the commands for you.

---

## Step 1: Create the database (Supabase)

1. Go to **supabase.com** and sign up (use your Gmail).
2. Click **New project**:
   - Name: `hydroclean-admin`
   - Database password: create a strong one and save it in your password manager.
   - Region: **Africa (Cape Town)** if offered, otherwise Europe (London/Frankfurt).
3. Wait about 2 minutes for it to finish.
4. Left menu → **SQL Editor** → **New query**. Open `supabase/schema.sql` from this folder, copy everything, paste it in and click **Run**. You should see "Success".
5. Left menu → **Authentication** → **Users** → **Add user** → **Create new user**:
   - Your email and a strong password. This is your admin login.
   - Tick **Auto Confirm User**.
6. **Lock sign-ups so nobody else can create an account:** Authentication → **Sign In / Providers** (or Settings) → turn **OFF** "Allow new users to sign up".
7. Project Settings → **API**. Copy two values for later:
   - **Project URL** (looks like `https://abcd1234.supabase.co`)
   - **anon public** key (a long code starting `eyJ…`; the anon key is safe to use in the app)

## Step 2: Try it on your computer (optional but recommended)

1. Install **Node.js** (LTS) from nodejs.org.
2. In this folder, copy `.env.example` to a new file called `.env` and paste in your Project URL and anon key.
3. In the VS Code terminal run:
   ```
   npm install
   npm run dev
   ```
4. Open the link it shows (http://localhost:5173) and log in with the user from Step 1.5.

## Step 3: Put it online (Vercel)

1. Create a free account at **github.com**, then create a new **private** repository called `hydroclean-admin` and upload this folder to it.
   - **Do NOT upload the `.env` file.** It's already excluded by `.gitignore`.
   - Claude Code can do this for you: "push this folder to a new private GitHub repo".
2. Go to **vercel.com** → sign up with GitHub → **Add New → Project** → import `hydroclean-admin`.
3. Before you click Deploy, open **Environment Variables** and add both:
   - `VITE_SUPABASE_URL` = your Project URL
   - `VITE_SUPABASE_ANON_KEY` = your anon key
4. Click **Deploy**. You'll get a link like `hydroclean-admin.vercel.app`. Test your login there.

## Step 4: Use admin.hydro-clean.co.za

1. In Vercel: your project → **Settings → Domains** → add `admin.hydro-clean.co.za`. Vercel will show a **CNAME** record (usually `cname.vercel-dns.com`).
2. In **Wix**: Dashboard → **Settings → Domains** → hydro-clean.co.za → **Manage DNS records** → under **CNAME** click **+ Add record**:
   - Host name: `admin`
   - Value: the target Vercel showed you (e.g. `cname.vercel-dns.com`)
   - Save.
3. Wait 10 minutes to a few hours. Vercel shows a green tick when it's live, and the padlock (HTTPS) is automatic.
4. Back in Supabase → **Authentication → URL Configuration**:
   - Set **Site URL** to `https://admin.hydro-clean.co.za`
   - Add the same address under **Redirect URLs**. This makes "Forgot password" emails work.

## Step 5: Add a discreet "Admin" link to your website (optional)

In the Wix editor, add a small text link in the footer, e.g. **Staff login**, linking to `https://admin.hydro-clean.co.za`. The admin is hidden from Google (noindex), so customers won't stumble on it.

---

## First things to do once you're in

1. **Settings:**
   - Check your business details, quote numbering, terms, and the WhatsApp and email outreach messages.
   - Paste your **Google review link** (Google Business Profile → "Ask for reviews" → copy link).
   - Add your banking details if you want them printed on quotes.
2. **Outreach → Import spreadsheet:** load the lead list from your scraper (Excel or CSV). Columns like *Business name, Phone, Email, Website, Town, Category* are matched automatically and duplicates are skipped.
3. **Clients:** add past customers so you can WhatsApp them for repeat summer cleans.

## How the pieces fit together

| You do this | The system does this |
|---|---|
| Tap **WhatsApp / Call / Email** on a lead | Opens your message pre-filled, marks the lead *Contacted*, sets a follow-up 4 days later |
| Tap **Quote** on a lead or client | Opens the quote builder pre-filled with their details |
| Build a quote → **Download PDF** | Your HydroClean quote layout. In the print window choose *Save as PDF* |
| **WhatsApp client** on a quote | Opens a chat with a ready message (attach the PDF) and marks the quote *Sent* |
| **Accepted → book job** | Creates the client and the job, and marks the lead *Won* |
| **Deposit / Payment received** on a job | Records the money in Finances automatically |
| **Ask for review** on a finished job | WhatsApps your Google review link |
| **Finances → Export** | Year's income and expenses as a spreadsheet for your accountant |

## Good to know

- **Security:** every table is locked so only your login can read or write your data, and sign-ups are switched off.
- **Phone:** it works on your phone. Open admin.hydro-clean.co.za in Chrome or Safari and choose "Add to Home Screen" for an app icon.
- **Backups:** Supabase free plan has no automatic backups. Once a month, export from Finances and Outreach, or upgrade Supabase later.
- **Free plan pause:** a free Supabase project pauses after about 1 week of **no use at all**. Logging in now and then keeps it awake. If it does pause, click "Restore" in Supabase.
- **POPIA:** keep first outreach messages as a polite question with an easy "no thanks", and mark anyone who says no as **Do not contact**. Their buttons are then disabled.
